
var ftmph = 0;
if(window.navigator.userAgent.indexOf("Firefox")>=1) {  ftmph = 16; }
var Butterlate = new Butterlation();
window._ = function(key) { return Butterlate.gettext(key); };
window.__ = function(key,replacements) { return Butterlate.vgettext(key,replacements); };

function Butterlation() {
  this.dict = new ButterDictionary();
  this.getLang = function() {
    var one, two, end;
    if((one=document.cookie.indexOf("language"))==-1) {
      //return ((navigator.language) ? navigator.language : navigator.browserLanguage).substring(0,2);
      return "en";
    }
    end = (document.cookie.indexOf(';',one)!=-1) ? document.cookie.indexOf(';',one) : document.cookie.length;
    return unescape(document.cookie.substring(one+9,end));
  };
  this.lang = this.getLang();
  this.setTextDomain = function(domain) { this.po=window.location.protocol+"//"+window.location.host+"/lang/"+this.lang+"/"+domain+".xml"; this.initializeDictionary(); }
  this.initializeDictionary = function() {
    var request;
    /*try { request = new XMLHttpRequest(); } catch(e1) {
      try { request = new ActiveXObject("Msxml2.XMLHTTP"); } catch(e2) {
        try { request = new ActiveXObject("Microsoft.XMLHTTP"); } catch(e3) { return; }}};*/
		
	if (window.XMLHttpRequest) { // Mozilla, Safari,...
        request = new XMLHttpRequest();
        if (request.overrideMimeType) {
            request.overrideMimeType('text/xml');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
            request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
        }
    }
    if (!request) {
        alert('Giving up :( Cannot create an XMLHTTP instance');
        return false;
    }
	
	var u = window.navigator.userAgent.toLocaleUpperCase();
	if((u.indexOf("IPAD") > 0) || (u.indexOf("IPHONE") > 0)){
		request.onreadystatechange = function(){
			if (request.readyState == 4) {
				if(request.status==200) {
					var pos = request.responseXML.documentElement.getElementsByTagName("message");
					for(var i=0; i<pos.length; i++){
						Butterlate.dict.set(pos[i].getAttribute("msgid"),pos[i].getAttribute("msgstr"));
					}
				}
			}
		};	
		request.open("GET",this.po,true);
	}else{
		request.open("GET",this.po,false);
		request.send(null);
		if(request.status==200) {
			var pos = request.responseXML.documentElement.getElementsByTagName("message");
			for(var i=0; i<pos.length; i++) this.dict.set(pos[i].getAttribute("msgid"),pos[i].getAttribute("msgstr"));
		}
	}
	if((u.indexOf("IPAD") > 0) || (u.indexOf("IPHONE") > 0)){
		request.send(null);
	}else{}
  };
  this.gettext = function(key) { return this.dict.get(key); };
  this.vgettext = function(key,replacements) {
    var nkey=this.gettext(key); var index; var count=0;
    if(replacements.length==0) return nkey;
    while((index=nkey.indexOf('%s'))!=-1) {
      nkey=nkey.substring(0,index)+replacements[count]+nkey.substring(index+2,nkey.length);
      count = ((count+1)==replacements.length) ? count : (count+1);
    }
    return nkey;
  };
}

function ButterDictionary() {
  this.keys = new Array();
  this.values = new Array();
  this.set = function(key,value) {
    var index = this.getIndex(key);
    if(index==-1) { this.keys.push(key); this.values.push(value); }
    else this.values[index]=value;
  };
  this.get = function(key) {
    var index;
    if((index=this.getIndex(key))!=-1) return this.values[index];
    return key;
  };
  this.getIndex = function(key) {
    var index=-1;
    for(var i=0; i<this.keys.length; i++) if(this.keys[i]==key) { index=i; break; }
    return index;
  };
  this.keyExists = function(key) { return (this.getIndex(key)!=1); };
  this.deleteKey = function(key) {
    var index = getIndex(key);
    if(index!=-1) { this.keys.splice(index,1); this.values.splice(index,1); }
  };
}
function gethiskey(str,str2,str3,str4,str5,str6,fxml) { var strs="NULL"; var str2s="NULL"; var str3s="NULL"; var str4s="NULL"; var str5s="NULL"; var str6s="NULL";
 this.getLang = function() { var one,two,end; if((one=document.cookie.indexOf("language"))==-1) { return "en"; } end = (document.cookie.indexOf(';',one)!=-1) ? document.cookie.indexOf(';',one) : document.cookie.length; return unescape(document.cookie.substring(one+9,end)); }; this.lang = this.getLang(); var request; try { request = new XMLHttpRequest(); } catch(e1) {      try { request = new ActiveXObject("Msxml2.XMLHTTP"); } catch(e2) {        try { request = new ActiveXObject("Microsoft.XMLHTTP"); } catch(e3) { return strs+"|"+str2s+"|"+str3s+"|"+str4s+"|"+str5s+"|"+str6s; }}};    request.open("GET",window.location.protocol+"//"+window.location.host+"/lang/"+this.lang+"/"+fxml+".xml",false);     request.send(null);    
 if(request.status==200) { var pos = request.responseXML.documentElement.getElementsByTagName("message"); for(var i=0; i<pos.length; i++) { if  ( pos[i].getAttribute("msgid") == str ) strs = pos[i].getAttribute("msgstr"); if  ( pos[i].getAttribute("msgid") == str2 ) { str2s = pos[i].getAttribute("msgstr"); } if ( pos[i].getAttribute("msgid") == str3 ) { str3s = pos[i].getAttribute("msgstr"); } if ( pos[i].getAttribute("msgid") == str4 ) { str4s = pos[i].getAttribute("msgstr"); } if ( pos[i].getAttribute("msgid") == str5 ) { str5s = pos[i].getAttribute("msgstr"); } if ( pos[i].getAttribute("msgid") == str6 ) { str6s = pos[i].getAttribute("msgstr"); return strs+"|"+str2s+"|"+str3s+"|"+str4s+"|"+str5s+"|"+str6s; } } return strs+"|"+str2s+"|"+str3s+"|"+str4s+"|"+str5s+"|"+str6s; }
}
function refrash(tmpf) { if(tmpf && !window.opera)   			{     							if ( ( window.navigator.userAgent.indexOf("Chrome")>=1 ) || ( window.navigator.userAgent.indexOf("Safari")>=1 ) || window.navigator.userAgent.indexOf("MSIE 9.0")>1 )	 						{	  										tmpf.height = 0;	 						}						tmpf.style.display = "block";      						if(tmpf.contentDocument && tmpf.contentDocument.body.offsetHeight)      							{        										tmpf.height = tmpf.contentDocument.body.offsetHeight + ftmph;				}      						else if (tmpf.Document && tmpf.document.body.scrollHeight)      							{        										tmpf.height = tmpf.document.body.scrollHeight;				}      						else    								{    				}   			}			else 	if (window.navigator.userAgent.substring(window.navigator.userAgent.search(/version/i)+8).substr(0,2) > "10" ) 	{		tmpf.height = tmpf.contentDocument.documentElement.offsetHeight;			}	else		{	  									tmpf.style.height = tmpf.contentDocument.documentElement.offsetHeight;	}				return true;	    }
function getCookie(c_name) { if (document.cookie.length>0) { c_start=document.cookie.indexOf(c_name + "=");if (c_start!=-1){c_start=c_start + c_name.length+1; c_end=document.cookie.indexOf(";",c_start); if (c_end==-1) { c_end=document.cookie.length; } return unescape(document.cookie.substring(c_start,c_end));} } return ""; }
function setCookie(c_name,value,expiredays){var exdate=new Date();exdate.setDate(exdate.getDate()+expiredays);document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : "; expires="+exdate.toGMTString());}
function style_display_on()
{
	if (window.ActiveXObject)
	{
		return "block";
	}
	else if (window.XMLHttpRequest)
	{
		return "table-row";
	}
}


function display_on()
{
  if(window.XMLHttpRequest){
    return "table-row";
  } else if(window.ActiveXObject){
    return "block";
  }
}


function isAllNumAndCh(str)
{
	for (var i=0; i<str.length; i++){
	    if((str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) >= 'a' && str.charAt(i) <= 'z')||(str.charAt(i) >= 'A' && str.charAt(i) <= 'Z'))
			continue;
		return 0;
	}
	return 1;
}


