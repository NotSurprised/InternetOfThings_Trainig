#!/bin/sh


#output HTTP header
echo "Pragma: no-cache\n"
echo "Cache-control: no-cache\n"
echo "Content-type: application/octet-stream"
echo "Content-Transfer-Encoding: binary"			#  "\n" make Un*x happy
echo "Content-Disposition: attachment; filename=\"RT2880_Log.dat\""
echo ""

echo "*********************minios time***********************"
cat /sbin/miniosTime 2>/dev/null
echo "*********************hameos time***********************"
cat /sbin/oem.in 2>/dev/null
if [ -f "/var/log/3g.log" ];then
echo "*********************3g********************************"
cat /var/log/3g.log 2>/dev/null
fi
if [ -f "/var/config/ppp/peers/hsdpa" ];then
echo "*********************ppp*******************************"
cat /var/config/ppp/peers/hsdpa 2>/dev/null
fi
if [ -f "/var/couldserver.log" ];then
echo "*********************couldserver***********************"
cat /var/couldserver.log 2>/dev/null
fi
echo "*******************************************************"
