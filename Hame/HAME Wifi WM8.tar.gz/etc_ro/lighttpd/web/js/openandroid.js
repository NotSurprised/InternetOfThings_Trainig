var app = {};
var nativeAppFun = {
    /***
        调起来源
    ***/
    launcher_type: '',

    openApp: function(opts) {
        var fn = function() {},
            defaultOpts = {
                newOpenAppUri: 'http://127.0.0.1:6259/sendintent?intent=' + window.encodeURIComponent(opts.openAppUri) + '&t=',
                openAppUri: ''
            },
            options = {},
            self = this;

        options = $.extend(defaultOpts, opts || {});

        options.checkSuccess = options.checkSuccess || function() {};
        options.checkError = options.checkError || function() {};

        this.checkApp(options, options.checkSuccess, options.checkError);
    },

    /**
     * zepto jsonp 在 安卓4以下版本无法出发404请求的error callback
     */

    jsonpy: function(o, d, f, a) {
        // random callback name in window scope
        var name = '__jsonp' + parseInt(Math.random() * 10000, 10),
            // url for request
            url = typeof o === 'string' ? o : o.url,
            // url parameter name containing callback name ('callback' usually)
            field = o.field || 'callback',
            // timeout for request (no timeout by default)
            timeout = o.timeout || false,
            timeoutId = null,

            script = document.createElement('script'),

            // execution status: null if not executed, 'done' or 'fail'
            status = null,
            // arguments for callbacks
            cbArgs = null,
            // callbacks collection
            callbacks = {
                done: [],
                fail: [],
                always: []
            },

            // promise object returned by jsonpy
            promise = {
                done: function(callback) {
                    callbacks.done.push(callback);
                    runCallbacks();

                    return promise;
                },

                fail: function(callback) {
                    callbacks.fail.push(callback);
                    runCallbacks();

                    return promise;
                },

                always: function(callback) {
                    callbacks.always.push(callback);
                    runCallbacks();

                    return promise;
                }
            },

            // helper function, run all callbacks in array with given args
            runCallbacksFromArray = function(cbs, args) {
                while (cb = cbs.shift()) {
                    cb.apply(this, args);
                }
            },

            // run all callbacks for current status; called by promise methods and setStatus()
            runCallbacks = function() {
                if (!status) return;

                runCallbacksFromArray(callbacks[status], cbArgs);
                runCallbacksFromArray(callbacks.always, cbArgs);
            },

            // set status to done or fail and set callback args
            // function may be called only once
            setStatus = function(success, args) {
                if (status) return;

                status = ['fail', 'done'][+success];
                cbArgs = args;
                runCallbacks();
            },



            // build url for request: simply add callback parameter to url
            buildUrl = function() {
                return url + ['?', '&'][+(url.indexOf('?') >= 0)] + [encodeURIComponent(field), encodeURIComponent(name)].join('=');
            },

            // initialize jsonpy
            init = function() {
                script.type = 'text/javascript';
                script.src = buildUrl();
                script.async = true;

                script.addEventListener('error', error, true);

                if (o.done) promise.done(o.done);
                if (o.fail) promise.fail(o.fail);
                if (o.always) promise.always(o.always);

                if (d) promise.done(d);
                if (f) promise.fail(f);
                if (a) promise.always(a);
            },

            // perform request
            connect = function() {
                window[name] = success;
                document.body.appendChild(script);
                if (timeout) {
                    timeoutId = setTimeout(error, timeout);
                }
            },

            // close connection and cleanup
            close = function() {
                if (status) return;

                delete window[name];
                document.body.removeChild(script);

                if (timeoutId) {
                    clearTimeout(timeoutId);
                    timeoutId = null;
                }
            },

            // called on request success
            success = function() {
                if (status) return;
                close();
                setStatus(true, arguments);
            },

            // called on request error or timeout (if exists)
            error = function() {
                if (status) return;
                close();
                setStatus(false, arguments);
            };


        init();
        connect();


        return promise;
    },
    /**
     * 检查app是否安装
     *
     * @param {Function} sfn 请求成功的回调函数
     * @param {Function} efn 请求失败的回调函数
     * @api private
     */
    checkApp: function(opts, sfn, efn) {
        //使用中间传值 避免多次重复请求请求检查
        // 1 => 正在检查
        // 2 => 已经安装
        // 0 => 没有安装
        app.appName = {};
        app.appName[opts.packageName] = 1;

        this.jsonpy({
            url: opts.newOpenAppUri + +new Date(),
            timeout: 2000,
            done: function(data) {
                if (data.error === 0) {
                    app.appName[opts.packageName] = 2;
                    sfn();
                } else {
                    app.appName[opts.packageName] = 0;
                    efn();
                }
            },
            fail: function() {
                app.appName[opts.packageName] = 0;
                efn();
            },
            always: function() {}
        });
    },

    openAndroid: function(opts) {
        var self = this,
            cb = opts.callback,
            cbError = (function() {
                return cb ? cb.error : function() {};
            })(),
            cbSuccess = (function() {
                return cb ? cb.success : function() {};
            })(),
            intent = this.intentMap[opts.type],
            data = opts.data,
            i = null,
            item = null;

        for (i in data) {
            intent = intent.replace('{' + i + '}', data[i]);
        }

        self.openApp({
            openAppUri: intent,
            checkError: cbError,
            checkSuccess: cbSuccess
        });
    },

    intentMap: {
        //  线上已有接口
        download: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/com.baidu.music.ui.UIMain;S.launcher_from=aladdin;S.type=download;l.songid={songid};S.allrate={allrate};i.charge={charge};i.havehigh={havehigh};S.launcher_type=' + this.launcher_type+ ';end',

        song: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/.activity.MusicPlayingActivity;S.launcher_from=aladdin;S.type=playsong;l.songid={songid};S.trackname={songname};S.artistname={artistname};S.launcher_type=' + this.launcher_type+ ';end',

        artist: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/com.baidu.music.ui.UIMain;S.launcher_from=aladdin;S.type=artist;l.artistid={artistid};S.launcher_type=' + this.launcher_type+ ';end',

        downloadSongs: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/com.baidu.music.ui.download.BatchDownloadSelectActivity;S.launcher_from=aladdin;S.type=batch_download;S.batch_download_type=artist;l.artistid={artistid};S.launcher_type=' + this.launcher_type+ ';end',

        downloadSongsNew: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/com.baidu.music.ui.download.BatchDownloadActivity;S.launcher_from=aladdin;S.type=batch_download;S.batch_download_type=artist;l.artistid={artistid};S.launcher_type=' + this.launcher_type+ ';end',

        open: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/com.baidu.music.ui.UIMain;S.launcher_from=aladdin;end',
        // 新接口，开发中1月3号发版

        songNew: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/.activity.MusicPlayingActivity;S.launcher_from=aladdin;S.type=playsong;S.songid={songid};S.launcher_type=' + this.launcher_type+ ';end',
        page: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/.activity.MusicPlayingActivity;S.launcher_from=aladdin;S.type={type};l.id={id};S.info={info};S.launcher_type=' + this.launcher_type+ ';end',
        share: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/.activity.MusicPlayingActivity;S.launcher_from=aladdin;S.type={type};S.title={title};S.artistname={artistname};l.songid={songid};S.launcher_type=' + this.launcher_type+ ';end',
        downloadNew: '#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=com.ting.mp3.android/com.baidu.music.ui.UIMain;S.launcher_from=aladdin;S.type=download;S.songid={songid};S.launcher_type=' + this.launcher_type+ ';end'
    }

};