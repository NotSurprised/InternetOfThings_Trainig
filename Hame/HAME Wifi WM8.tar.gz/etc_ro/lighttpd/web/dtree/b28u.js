function $(element){return document.getElementById(element);}
function geton_m(a){$("m"+a).className="menubg:hover";}
function getover_m(a){$("m"+a).className="menubg";}
function geton(a){$("t"+a).className="news_on";}
function getover(a){$("t"+a).className="news_line";}
function geton1(a){$("s"+a).className="gcimg_on";}
function getover1(a){$("s"+a).className="gcimg";}
function showHide(e,objname){var obj=getObject(objname);if(obj.style.display=="none"){obj.style.display="block";e.className="xias";}else {obj.style.display="none";e.className="rights";}}
function HM_showHideLayers() {   var i,p,v,obj,args=HM_showHideLayers.arguments;  for (i=0; i<(args.length-2); i+=3)   with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }    obj.visibility=v; }}	 