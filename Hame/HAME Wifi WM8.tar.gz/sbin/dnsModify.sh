#!/bin/sh

connstatus=$(cat /var/rom/connstatus)
if [[ $connstatus -eq 1 ]];then
    dns=$(sed -n '/option dns/=' /etc/udhcpd.conf)
    if [ ! -n "$dns" ];then
        dhcpPriDns=`nvram_get 2860 dhcpPriDns`
        dhcpSecDns=`nvram_get 2860 dhcpSecDns`
        sed -i "/^option subnet/a\option dns $dhcpPriDns $dhcpSecDns" /etc/udhcpd.conf
        echo "add dns" > /dev/console
    fi
else
    line=$(sed -n '/option dns/=' /etc/udhcpd.conf)
    sed -i $line','1'd' /etc/udhcpd.conf
    echo "delete dns" > /dev/console
fi

killall -q udhcpd 2>/dev/null

udhcpd /etc/udhcpd.conf &

useap=`nvram_get 2860 USEAP`
wanmode=`nvram_get 2860 wanConnectionMode`

echo -e "1\c" > /var/rom/wificonnstatus
if [ "$wanmode" != "WIFI" ]; then
    /sbin/wireless.sh

    if [[ $connstatus -eq 1 ]];then

        if [ "$wanmode" = "PPPOE" ] || [ "$wanmode" = "DHCP" ]; then
            killall -9 udhcpc;udhcpc -i eth2.2 -s /sbin/udhcpc.sh &
        elif [ "$wanmode" = "WIFI" ]; then
            if [ "$useap" = "1" ]; then
                killall -9 udhcpc;udhcpc -i apcli0 -s /sbin/udhcpc.sh &
            else
                killall -9 udhcpc;udhcpc -i ra0 -s /sbin/udhcpc.sh &
            fi

        fi
    fi

    sleep 2;
    ifconfig apcli0 down
fi 
rm /var/rom/wificonnstatus
