#!/bin/sh

# udhcpc script edited by Tim Riker <Tim@Rikers.org>

. /sbin/config.sh
. /sbin/global.sh

useap=`nvram_get 2860 USEAP`

[ -z "$1" ] && echo "Error: should be called from udhcpc" && exit 1

RESOLV_CONF="/etc/resolv.conf"
[ -n "$broadcast" ] && BROADCAST="broadcast $broadcast"
[ -n "$subnet" ] && NETMASK="netmask $subnet"

case "$1" in
    deconfig)
        /sbin/ifconfig $interface 0.0.0.0
        ;;

    renew|bound)
        /sbin/ifconfig $interface $ip $BROADCAST $NETMASK

        /* remove all binding entries after getting new IP */
        HWNAT=`nvram_get 2860 hwnatEnabled`
        if [ "$HWNAT" = "1" ]; then
                rmmod hw_nat
                insmod -q hw_nat
        fi

        if [ -n "$router" ] ; then
            echo "deleting routers"
            while route del default gw 0.0.0.0 dev $interface ; do
                :
            done

            metric=0
            for i in $router ; do
                metric=`expr $metric + 1`
                route add default gw $i dev $interface metric $metric
            done
        fi

        echo -n > $RESOLV_CONF
        [ -n "$domain" ] && echo search $domain >> $RESOLV_CONF
        for i in $dns ; do
            echo adding dns $i
            echo nameserver $i >> $RESOLV_CONF
        done
                # notify goahead when the WAN IP has been acquired. --yy
                # killall -SIGTSTP goahead
                # sleep 3
                #killall -SIGTSTP nvram_daemon
                if [ "$wanmode" = "WIFI" ]; then
                    echo -e "1\c" > /var/rom/connstatus
                    lan_ip=`nvram_get 2860 lan_ipaddr`
                    if [ "$useap" = "1" ]; then
                        iptables -t nat -A POSTROUTING -s $lan_ip/24 -o apcli0 -j MASQUERADE
                    else
                        iptables -t nat -A POSTROUTING -s $lan_ip/24 -o ra0 -j MASQUERADE
                    fi
                fi
                
                # restart igmpproxy daemon
                config-igmpproxy.sh
                if [ "$wanmode" = "L2TP" ]; then
                        if [ "$CONFIG_PPPOL2TP" == "y" ]; then
                                killall openl2tpd
                                openl2tpd
                        else
                                killall l2tpd
                                l2tpd
                                sleep 1
                                l2tp-control "start-session $l2tp_srv"
                        fi
                elif [ "$wanmode" = "PPTP" ]; then
                        killall pppd
                        pppd file /etc/options.pptp  &
                fi

                if [ "$wanmode" = "STATIC" ] || [ "$wanmode" = "DHCP" ]; then
                    echo -e "1\c" > /var/rom/connstatus
                    lan_ip=`nvram_get 2860 lan_ipaddr`
                    iptables -t nat -A POSTROUTING -s $lan_ip/24 -o eth2.2 -j MASQUERADE
                fi

                cat /var/run/3g.pid | xargs kill -SIGTSTP

                echo $wanmode > /dev/console
				echo "---- udhcpc.sh----" > /dev/console
                echo 1 > /var/reloadandroidplayer
                /sbin/ntp.sh
        ;;
esac

exit 0