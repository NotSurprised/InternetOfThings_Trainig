#!/bin/sh
#time:20170503
#name:qing

timecount=0
while :
do
	if [ $timecount -ne 15 ]; then
		watchdog &
	else
		startdlna &
		timecount=0
		
		ps -fe|grep spotify |grep -v grep | grep -v avahi-publish-service
		if [ $? -ne 0 ]; then
			echo "spotify no "
			cd /sbin; spotify&
		fi
	fi
	
	timecount=`expr $timecount + 1`
	sleep 2

done
