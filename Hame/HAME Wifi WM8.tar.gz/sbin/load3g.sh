#!/bin/sh
# vdivint=`nvram_get 2860 divint`
# vdivcomp=`nvram_get 2860 divcomp`
input8960=`nvram_get 2860 INPUT8960`

insmod /lib/modules/2.6.36/kernel/drivers/ralink_gdma.ko

if [ "$input8960" = "8960" ]; then
	insmod /lib/modules/2.6.36/kernel/drivers/i2c_drv.ko input8960=8960
else
	insmod /lib/modules/2.6.36/kernel/drivers/i2c_drv.ko
fi
insmod /lib/modules/2.6.36/kernel/drivers/ralink_i2s.ko
insmod /lib/modules/2.6.36/kernel/drivers/ralink_wdt.ko

#gpio l 23 0 4000 0 0 0

mkdir -p /var/log

mkdir -p /etc/avahi
mkdir -p /etc/avahi/services
mkdir -p /etc/dbus-1
mkdir -p /etc/dbus-1/system.d
mkdir -p /var/run/dbus
avahi-daemon.sh
dbus.sh
dbus-daemon --config-file=/etc/dbus-1/system.conf &
sta_connect_check.sh &

echo -e "1\c" > /var/rom/OpenSound
echo -e "1\c" > /var/rom/networksetup

weixin read /var/t1 &

speaker &

cd /bin
/bin/androidplayer &
startapple &
localMusic &

watchDog.sh &

cd /sbin; spotify&
