#!/bin/sh
HOST_NAME=`nvram_get 2860 SSID1`
AVAHI_FILE=/etc/avahi/avahi-daemon.conf

echo '[server]' > $AVAHI_FILE
echo "host-name=$HOST_NAME" >> $AVAHI_FILE
echo "#domain-name=router.3g" >> $AVAHI_FILE
echo "#browse-domains=$HOST_NAME" >> $AVAHI_FILE
echo 'use-ipv4=yes' >> $AVAHI_FILE
echo 'use-ipv6=no' >> $AVAHI_FILE
echo '#check-response-ttl=no' >> $AVAHI_FILE
echo '#use-iff-running=no' >> $AVAHI_FILE
echo '#enable-dbus=yes' >> $AVAHI_FILE
echo '#disallow-other-stacks=no' >> $AVAHI_FILE
echo '#allow-point-to-point=no' >> $AVAHI_FILE
echo '' >> $AVAHI_FILE
echo '[wide-area]' >> $AVAHI_FILE
echo 'enable-wide-area=yes' >> $AVAHI_FILE
echo '' >> $AVAHI_FILE
echo '[publish]' >> $AVAHI_FILE
echo '#disable-publishing=no' >> $AVAHI_FILE
echo '#disable-user-service-publishing=no' >> $AVAHI_FILE
echo '#add-service-cookie=yes' >> $AVAHI_FILE
echo '#publish-addresses=yes' >> $AVAHI_FILE
echo '#publish-hinfo=yes' >> $AVAHI_FILE
echo '#publish-workstation=yes' >> $AVAHI_FILE
echo '#publish-domain=yes' >> $AVAHI_FILE
echo '#publish-dns-servers=192.168.50.1, 192.168.50.2' >> $AVAHI_FILE
echo '#publish-resolv-conf-dns-servers=yes' >> $AVAHI_FILE
echo '' >> $AVAHI_FILE
echo '[reflector]' >> $AVAHI_FILE
echo '#enable-reflector=no' >> $AVAHI_FILE
echo '#reflect-ipv=no' >> $AVAHI_FILE
echo '' >> $AVAHI_FILE
echo '[rlimits]' >> $AVAHI_FILE
echo '#rlimit-as=' >> $AVAHI_FILE
echo 'rlimit-core=0' >> $AVAHI_FILE
echo 'rlimit-data=4194304' >> $AVAHI_FILE
echo 'rlimit-fsize=0' >> $AVAHI_FILE
echo 'rlimit-nofile=30' >> $AVAHI_FILE
echo 'rlimit-stack=4194304' >> $AVAHI_FILE
echo 'rlimit-nproc=3' >> $AVAHI_FILE
echo '' >> $AVAHI_FILE