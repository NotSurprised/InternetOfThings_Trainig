#!/bin/sh

useap=`nvram_get 2860 USEAP`
wanmode=`nvram_get 2860 wanConnectionMode`

starttime=$(cat /proc/uptime | awk '{print $1}'|awk -F '.' '{print $1}')

port="ra0"

if [ "$useap" = "1" ]; then
    port="apcli0"
fi

ip=$(ifconfig $port|sed -n '/inet addr/s/^[^:]*:\([0-9.]\{7,15\}\) .*/\1/p')

outtime=20

echo $ip
if [ "$wanmode" = "WIFI" ]; then
    echo "wanmode wifi"
    echo "useap " $useap
    temp=0
    while [[ "$ip" == "" ]]
    do
        sleep 3
        runtime=$(cat /proc/uptime | awk '{print $1}'|awk -F '.' '{print $1}')
        temp=`expr $runtime - $starttime`
        echo "outtime:" $outtime  "temp:" $temp
        if [ "$temp" -gt "$outtime" ]; then
            echo "timeout open ap model" $runtime $starttime
            ApAndStaSwitch 3 &
            break
        fi

        ip=$(ifconfig $port|sed -n '/inet addr/s/^[^:]*:\([0-9.]\{7,15\}\) .*/\1/p')
    done
fi