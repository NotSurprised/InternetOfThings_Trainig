#!/bin/sh
killall -KILL appleplayer
killall -KILL spotify
killall -KILL dbus-daemon
killall -KILL speaker