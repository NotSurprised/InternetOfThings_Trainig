#!/bin/sh
cat /var/run/androidplayer.pid | xargs kill -97
sleep 2
killall -9 androidplayer
killall -9 speaker
sleep 1
speaker &
cd /bin
/bin/androidplayer &


