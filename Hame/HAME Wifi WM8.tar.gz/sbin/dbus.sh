#!/bin/sh
LOGIN_USER=`nvram_get 2860 Login`
DBUS_FILE=/etc/dbus-1/system.conf
echo '<busconfig>' > $DBUS_FILE
echo '<type>system</type>' >> $DBUS_FILE
echo "<user>$LOGIN_USER</user>" >> $DBUS_FILE
echo '<fork/>' >> $DBUS_FILE
echo '<pidfile>/var/run/messagebus.pid</pidfile>' >> $DBUS_FILE
echo '<auth>EXTERNAL</auth>' >> $DBUS_FILE
echo '<listen>unix:path=/var/run/dbus/system_bus_socket</listen>' >> $DBUS_FILE
echo '<policy context="default">' >> $DBUS_FILE
echo '<allow send_interface="*"/>' >> $DBUS_FILE
echo '<allow receive_interface="*"/>' >> $DBUS_FILE
echo '<allow own="*"/>' >> $DBUS_FILE
echo '<allow user="*"/>' >> $DBUS_FILE
echo '<allow send_destination="org.freedesktop.DBus"/>' >> $DBUS_FILE
echo '<allow receive_sender="org.freedesktop.DBus"/>' >> $DBUS_FILE
echo '<allow send_requested_reply="true"/>' >> $DBUS_FILE
echo '<allow receive_requested_reply="true"/>' >> $DBUS_FILE
echo '</policy>' >> $DBUS_FILE
echo '<includedir>system.d</includedir>' >> $DBUS_FILE
echo '<include if_selinux_enabled="yes" selinux_root_relative="yes">contexts/dbus_contexts</include>' >> $DBUS_FILE
echo '</busconfig>' >> $DBUS_FILE

